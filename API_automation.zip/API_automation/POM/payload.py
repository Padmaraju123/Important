def Post_addbook_Payload(aisle_val):
    book_payload = {
        "name": "Learn Appium Automation with Java",
        "isbn": "kycc",
        "aisle": aisle_val,
        "author": "raju"
    }

    return book_payload
