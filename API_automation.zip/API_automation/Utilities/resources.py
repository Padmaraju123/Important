class Api_resources:
    getbook = "/Library/GetBook.php"
    delbook = "/Library/DeleteBook.php"
    addbook = "/Library/Addbook.php"
